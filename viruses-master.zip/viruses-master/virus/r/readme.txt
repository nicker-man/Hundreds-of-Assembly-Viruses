
Official Alliance Virii Archives:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Maintained and Managed by Rhys and Hasy

	This is one of many ZIP archive files that, all together, contain
	literally thousands of working, running virii.  Enjoy.

	All you must do to avoid infection is make sure that no idiot 
	runs these.

	These virii are for educational uses only.  I will not be 
	responsible for what you do with these.

					 - Rhys
					 http://www.ilf.net/rdu/
	
	I have added some new virii.
	History:
	V 1: 611 virii
	V 2: 752 virii
	V 3: 798 virii
			
			- Hasy
			  http://www.angelfire.com/al/hasy/
