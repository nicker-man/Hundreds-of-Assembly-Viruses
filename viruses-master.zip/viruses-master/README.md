# Viruses

Viruses are nowadays just a continual annoyance but back when thing were shiny and new there was some "Cred" to making a real virus.

This repository contains the source code to several hundred viruses from the twentieth century. Main of these have been regenerated from the binaries, but some, incuding some of the more (in)famous ones, are the original source of the authors.

There are no actual compiled viruses in this repository, but if you do compile anything it is possibly, though rather unlikely, that you will damage your computer. ... Don't do that.

Despite the fact that this repository just contains source files you will probably lose some of them to your AV if you download it on Windows. DO NOT turn off your AV, just look at those files on github.

The repository also contains a copy of the VCL v1.0 (which your AV will probably HATE).
```
                               Nowhere Man's

     ▓▓▓▓▓▓▓       ▓▓▓▓▓▓▓      ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓      ▓▓▓▓▓▓▓▓▓
     ▓▓▓▓▓▓▓       ▓▓▓▓▓▓▓     ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓      ▓▓▓▓▓▓▓
     ▓▓▓▓▓▓▓       ▓▓▓▓▓▓▓     ▓▓▓▓▓▓        ▓▓▓▓▓▓      ▓▓▓▓▓▓▓
     ▓▓▓▓▓▓▓       ▓▓▓▓▓▓▓     ▓▓▓▓▓▓                    ▓▓▓▓▓▓▓
     ▓▓▓▓▓▓▓       ▓▓▓▓▓▓▓     ▓▓▓▓▓▓                    ▓▓▓▓▓▓▓
     ▓▓▓▓▓▓▓       ▓▓▓▓▓▓▓     ▓▓▓▓▓▓                    ▓▓▓▓▓▓▓
      ▓▓▓▓▓▓▓     ▓▓▓▓▓▓▓      ▓▓▓▓▓▓                    ▓▓▓▓▓▓▓
       ▓▓▓▓▓▓▓   ▓▓▓▓▓▓▓       ▓▓▓▓▓▓                    ▓▓▓▓▓▓▓
        ▓▓▓▓▓▓▓ ▓▓▓▓▓▓▓        ▓▓▓▓▓▓                    ▓▓▓▓▓▓▓      ▓▓▓▓
         ▓▓▓▓▓▓▓▓▓▓▓▓▓         ▓▓▓▓▓▓        ▓▓▓▓▓▓      ▓▓▓▓▓▓▓     ▓▓▓▓▓
          ▓▓▓▓▓▓▓▓▓▓▓          ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓      ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
           ▓▓▓▓▓▓▓▓▓            ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓      ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓

             Virus                   Creation               Laboratory


                               Version 1.00

              Copyright (c) 1992 Nowhere Man and [NuKE] WaReZ

```

Once again DO NOT COMPILE ANYTHING from this repository, some of the code in this repository WILL run on Windows.
